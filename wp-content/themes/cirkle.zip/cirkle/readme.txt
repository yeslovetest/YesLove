=== Cirkle === 
Contributors: RadiusTheme
@since   1.0
Version: 1.1.5
ChangeLog:
1. Registratiom form issue Fixed.
2. WooCommerce outdated template update.

We developed this theme for any kind of Social Networking and circle group chat. Before install this theme please read the documentation file carefully. If you have any questions or any queries or any problem please contact us throw by email address. Thank you for purchase Cirkle WordPress Theme.

