<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\cirkle;

get_template_part( 'template-parts/content', get_post_format() );

?>
