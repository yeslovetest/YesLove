<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\cirkle;
use radiustheme\cirkle\RDTheme;
?>

		</div>
	</div>

	<?php
        get_template_part('template-parts/footer/footer', RDTheme::$options['shop_footer_style']);
    ?>

<?php wp_footer(); ?>

</div>
</body>
</html>