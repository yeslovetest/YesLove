const Loader = () => {
    return <div className="cirkle-loader"></div>;
}

export default Loader;
