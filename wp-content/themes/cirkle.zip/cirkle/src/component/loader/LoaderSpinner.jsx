const LoaderSpinner = () => {
    return (
        <div className="loader-spinner-wrap">
            <div className="loader-spinner"></div>
        </div>
    );
}

export default LoaderSpinner;