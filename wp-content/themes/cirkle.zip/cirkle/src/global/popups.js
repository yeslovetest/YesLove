import plugins from '../helper/plugins';

plugins.createPopup({
  trigger: '#post-open-gallery-popup-trigger',
  type: 'gallery'
});